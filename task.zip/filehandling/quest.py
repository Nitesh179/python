import os

# current directory
'''cwd=os.getcwd()
print("current working directory : ",cwd)

# to remove directory

os.rmdir('dirname')
print("directory is deleted...")'''


# To know contents of directory

# print(os.listdir())

# get information about file :

print(os.stat('meta.avif'))