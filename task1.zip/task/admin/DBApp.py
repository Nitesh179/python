import os,sys

while True:
    print("\n")