# image copied and write to other file :

'''f=open('meta2.jpg','rb')
# print(f.read())

f1=open('meta.avif','wb')
img=f.read()

f1.write(img)
print("image copied succesfully !!!")'''









